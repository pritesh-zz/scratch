tinyMCE.addI18n('ro.searchreplace_dlg',{
searchnext_desc:"Caut\u0103 din nou",
notfound:"C\u0103utarea a fost terminat\u0103. Nu am g\u0103sit termenul c\u0103utat.",
search_title:"Caut\u0103",
replace_title:"Caut\u0103/\u00CEnlocuie\u015Fte",
allreplaced:"Toate instan\u0163ele termenului c\u0103utat au fost \u00EEnlocuite.",
findwhat:"Termen c\u0103utat:",
replacewith:"\u00CEnlocuie\u015Fte cu:",
direction:"Direc\u0163ia",
up:"\u00CEn sus",
down:"\u00CEn jos",
mcase:"Conteaz\u0103 litere mici/mari?",
findnext:"Caut\u0103 urm\u0103torul",
replace:"\u00CEnlocuie\u015Fte",
replaceall:"\u00CEnlocuie\u015Fte toate"
});
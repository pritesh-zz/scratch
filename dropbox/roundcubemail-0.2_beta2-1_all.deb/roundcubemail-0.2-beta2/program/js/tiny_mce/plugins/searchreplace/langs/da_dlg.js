tinyMCE.addI18n('da.searchreplace_dlg',{
searchnext_desc:"S\u00F8g igen",
notfound:"S\u00F8gningen gav intet resultat.",
search_title:"S\u00F8g",
replace_title:"S\u00F8g / Erstate",
allreplaced:"Alle forekomster af s\u00F8gestrengen er erstattet.",
findwhat:"S\u00F8g efter",
replacewith:"Erstat med",
direction:"Retning",
up:"Op",
down:"Ned",
mcase:"Forskel p\u00E5 store og sm\u00E5 bogstaver",
findnext:"Find n\u00E6ste",
replace:"Erstat",
replaceall:"Erstat alle"
});
tinyMCE.addI18n('nl.searchreplace_dlg',{
searchnext_desc:"Opnieuw zoeken",
notfound:"Het doorzoeken is voltooid. De zoekterm kon niet meer worden gevonden.",
search_title:"Zoeken",
replace_title:"Zoeken/Vervangen",
allreplaced:"Alle instanties van de zoekterm zijn vervangen.",
findwhat:"Zoeken naar",
replacewith:"Vervangen door",
direction:"Richting",
up:"Omhoog",
down:"Omlaag",
mcase:"Identieke hoofdletters/kleine letters",
findnext:"Zoeken",
replace:"Vervangen",
replaceall:"Alles verv."
});